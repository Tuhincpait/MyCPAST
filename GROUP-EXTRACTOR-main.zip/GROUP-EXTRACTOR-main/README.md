<h1 align="center"> [Nasir Ahmed]</h1>

<h2 align="center">  PAID TOOL </h2>


## <b>installation</b>



- `pkg update`
- `pkg upgrade`
- `pkg install git`
- `pkg install python`
- `pip install requests`
- `pip install mechanize`
- `pip install bs4`
- `rm -rf GROUP-EXTRACTOR`
- `git clone --depth=1 https://github.com/GWTBD/GROUP-EXTRACTOR.git`
- `cd GROUP-EXTRACTOR`
- `python deta.py`


 ___This Tools is Paid___</br>
